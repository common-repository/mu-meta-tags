<?php
/*
Plugin Name: MU Meta Tags
Plugin URI: http://coyotesdesigns.com
Description: MU Meta Tags adds support for defining unique meta tags for themes referenced by multiple web sites. This is often the case with web sites running on the MU framework where more than one reference exists to the same theme.
Author: Coyote
Author URI: http://coyotesdesigns.com
Version: 0.99
*/

if ( is_admin() ) {
	add_action( 'admin_menu', 'mu_meta_menu' );
	add_action( 'admin_init', 'register_mu_meta_settings' );
} else {
}

function mu_meta_menu() {
	add_options_page('Meta Tags', 'Meta Tags', 10, 'mu-meta-group', 'meta_options_page');
}

function register_mu_meta_settings() {
	register_setting( 'mu-meta-group', 'verify-v1' );
	register_setting( 'mu-meta-group', 'meta_keywords' );
	register_setting( 'mu-meta-group', 'meta_description' );
	register_setting( 'mu-meta-group', 'meta_abstract' );
	register_setting( 'mu-meta-group', 'favorite_icon' );
}

function mu_metadata() {
	echo "<link rel='shortcut icon' type='image/x-icon' href='". get_option('favorite_icon')."' />\r\n";
	echo "<link rel='icon' href='". get_option('favorite_icon')."' type='image/x-icon' />\r\n";
	echo "<meta name='keywords' content='". get_option('meta_keywords')."' />\r\n";
	echo "<meta name='description' content='". get_option('meta_description')."' />\r\n";
	echo "<meta name='abstract' content='". get_option('meta_description')."' />\r\n";
	echo "<meta name='verify-v1' content='".get_option('verify-v1')."' />\r\n\r\n";
}

add_action('wp_head', 'mu_metadata');


function meta_options_page() {

?>

<div class="wrap">
<h2>MU Meta Tags</h2>
<p>Here you define the meta tags values that will be placed within the theme header.</p>
<form method="post" action="options.php">

<?php settings_fields( 'mu-meta-group' ); ?>

<table class="form-table">

<tr valign="top">
<th scope="row">Google meta tag verification code</th>
<td><input type="text" name="verify-v1" size="64" value="<?php echo get_option('verify-v1'); ?>" /></td>
</tr>

<tr valign="top">
<th scope="row">Document Keyword List</th>
<td><input type="text" name="meta_keywords" size="64" value="<?php echo get_option('meta_keywords'); ?>" /></td>
</tr>

<tr valign="top">
<th scope="row">Document Description</th>
<td><input type="text" name="meta_description" size="64" value="<?php echo get_option('meta_description'); ?>" /></td>
</tr>

<tr valign="top">
<th scope="row">Document Abstract</th>
<td><input type="text" name="meta_abstract" size="64" value="<?php echo get_option('meta_abstract'); ?>" /></td>
</tr>

<tr valign="top">
<th scope="row">Favorite Icon URL</th>
<td><input type="text" name="favorite_icon" size="64" value="<?php echo get_option('favorite_icon'); ?>" /></td>
</tr>

</table>

<p class="submit">
<input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
</p>

</form>
</div>

<?php
}
?>
